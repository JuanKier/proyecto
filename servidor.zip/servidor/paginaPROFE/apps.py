from django.apps import AppConfig


class PaginaConfig(AppConfig):
    name = 'pagina'
